<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Fruites List')); ?></div>

                <div class="card-body">
                    <div class="accordion" id="accordionExample">

                        <ul id="myUL">
                            <?php $__currentLoopData = $fruites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <span class="caret">
                                    <?php echo e($fruite->label); ?>

                                </span>
                                <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($fruite->id); ?>">
                                    Edit
                                </button>
                                <?php if (isset($component)) { $__componentOriginal0aeda31c8052c3f089130364da9b3b2922c850c3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\EditComponent::class, ['fruit' => $fruite] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('edit-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\EditComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0aeda31c8052c3f089130364da9b3b2922c850c3)): ?>
<?php $component = $__componentOriginal0aeda31c8052c3f089130364da9b3b2922c850c3; ?>
<?php unset($__componentOriginal0aeda31c8052c3f089130364da9b3b2922c850c3); ?>
<?php endif; ?>
                                <?php if($fruite->children->count() > 0): ?>
                                <?php if (isset($component)) { $__componentOriginalc2837de8c1f256e19584f0e34adf537fe8be6719 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ListComponent::class, ['id' => $fruite->id] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('list-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ListComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2837de8c1f256e19584f0e34adf537fe8be6719)): ?>
<?php $component = $__componentOriginalc2837de8c1f256e19584f0e34adf537fe8be6719; ?>
<?php unset($__componentOriginalc2837de8c1f256e19584f0e34adf537fe8be6719); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/apple/Laravel/Fiverr/listing-json-with-cron-job/resources/views/welcome.blade.php ENDPATH**/ ?>